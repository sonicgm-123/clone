const menu = document.querySelector('.menu');
const abrir = document.querySelector('.menu-resp');
const fechar = document.querySelector('.fechar');

function fecharMenu() {
  menu.classList.remove('aberto');
  abrir.setAttribute('aria-expanded', 'false');
}

abrir.addEventListener('click', () => {
  menu.classList.add('aberto');
  abrir.setAttribute('aria-expanded', 'true');
});

fechar.addEventListener('click', fecharMenu);
menu.querySelectorAll('a').forEach(link => link.addEventListener('click', fecharMenu));

document.querySelector('.form-contato').addEventListener('submit', event => {
  event.preventDefault();
  alert('Este formulário é apenas visual e ainda não está conectado a um servidor.');
});
